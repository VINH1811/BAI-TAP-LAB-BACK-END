﻿using LAB03_NVV.Models;
using Microsoft.AspNetCore.Mvc;

namespace LAB03_NVV.Controllers
{
    public class ProductController : Controller
    {
        static List<Product> products = new List<Product>()
        {
            new Product { Id = 1, Name = "Iphone", Price = 1000 },
            new Product { Id = 2, Name = "Samsung", Price = 800 },
            new Product { Id = 3, Name = "Xiaomi", Price = 500 },
        };

        public IActionResult Index()
        {
            return View(products);
        }
        public IActionResult Detail()
        {
            return View();
        }
        public IActionResult Save(Product pro)
        {
            products.Add(pro);
            return RedirectToAction("Index");
        }
    }
}
