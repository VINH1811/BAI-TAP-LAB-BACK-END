﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Diem
{
    public float x, y;

    public Diem() { }

    public Diem(float x, float y)
    {
        this.x = x;
        this.y = y;
    }

    public void Nhap()
    {
        Console.Write("  Nhập hoành độ: ");
        x = float.Parse(Console.ReadLine());
        Console.Write("  Nhập tung độ: ");
        y = float.Parse(Console.ReadLine());
    }

    public void Hien()
    {
        Console.Write($"({x}, {y})");
    }

    public float TinhKhoangCach(Diem d2)
    {
        return (float)Math.Sqrt(Math.Pow(x - d2.x, 2) + Math.Pow(y - d2.y, 2));
    }
}
