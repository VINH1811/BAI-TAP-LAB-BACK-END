﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class QuanLyHinhTron
{
    private List<HinhTron> danhSach = new List<HinhTron>();

    public void NhapDanhSach()
    {
        Console.Write("Nhập số lượng hình tròn: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"--- Nhập hình tròn thứ {i + 1} ---");
            HinhTron ht = new HinhTron();
            ht.Nhap();
            danhSach.Add(ht);
        }
    }

    public void HienDanhSach()
    {
        Console.WriteLine("\n=== DANH SÁCH HÌNH TRÒN ===");
        for (int i = 0; i < danhSach.Count; i++)
        {
            Console.Write($"Hình tròn {i + 1}: ");
            danhSach[i].Hien();
        }
    }

    public void TimHinhTronGiaoNhieuNhat()
    {
        int maxGiao = -1;
        int index = -1;

        for (int i = 0; i < danhSach.Count; i++)
        {
            int dem = 0;
            for (int j = 0; j < danhSach.Count; j++)
            {
                if (i != j && danhSach[i].GiaoNhau(danhSach[j]))
                {
                    dem++;
                }
            }

            if (dem > maxGiao)
            {
                maxGiao = dem;
                index = i;
            }
        }

        if (index != -1)
        {
            Console.WriteLine($"\nHình tròn giao với nhiều hình tròn khác nhất ({maxGiao} hình):");
            danhSach[index].Hien();
        }
        else
        {
            Console.WriteLine("\nKhông có hình tròn nào giao nhau.");
        }
    }
}
