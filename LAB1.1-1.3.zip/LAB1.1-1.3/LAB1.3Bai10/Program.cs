﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        VanBan vanBan = new VanBan();
        int chon;

        do
        {
            Console.WriteLine("\n====== MENU ======");
            Console.WriteLine("1. Nhập văn bản");
            Console.WriteLine("2. Hiển thị văn bản");
            Console.WriteLine("3. Đếm số từ trong văn bản");
            Console.WriteLine("4. Đếm số ký tự 'H' hoặc 'h'");
            Console.WriteLine("5. Chuẩn hóa văn bản");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    vanBan.NhapVanBan();
                    break;
                case 2:
                    vanBan.XuatVanBan();
                    break;
                case 3:
                    Console.WriteLine($"Số từ trong văn bản: {vanBan.DemSoTu()}");
                    break;
                case 4:
                    Console.WriteLine($"Số ký tự 'H' hoặc 'h': {vanBan.DemSoKyTuH()}");
                    break;
                case 5:
                    string chuanHoa = vanBan.ChuanHoa();
                    Console.WriteLine($"Văn bản sau chuẩn hóa: \"{chuanHoa}\"");
                    break;
                case 0:
                    Console.WriteLine("Kết thúc chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    break;
            }

        } while (chon != 0);
    }
}
