﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QLHoiVien
{
    private List<HoiVien> danhSach = new List<HoiVien>();

    public void Nhap()
    {
        Console.Write("Nhập số hội viên: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"--- Hội viên thứ {i + 1} ---");
            Console.WriteLine("1. Đã có gia đình");
            Console.WriteLine("2. Có người yêu");
            Console.WriteLine("3. Chưa có người yêu");
            Console.Write("Chọn loại hội viên (1/2/3): ");
            int loai = int.Parse(Console.ReadLine());

            HoiVien hv;
            if (loai == 1)
                hv = new HoiVienCoGiaDinh();
            else if (loai == 2)
                hv = new HoiVienCoNguoiYeu();
            else
                hv = new HoiVien();

            hv.Nhap();
            danhSach.Add(hv);
        }
    }

    public void TimNgayCuoi()
    {
        Console.WriteLine("Các hội viên có ngày cưới là 11/11/2011:");
        foreach (var hv in danhSach)
        {
            if (hv is HoiVienCoGiaDinh gd && gd.NgayCuoi == new DateTime(2011, 11, 11))
            {
                gd.Xuat();
                Console.WriteLine("--------------------");
            }
        }
    }

    public void HienThiCoNguoiYeuChuaCuoi()
    {
        Console.WriteLine("Các hội viên có người yêu nhưng chưa cưới:");
        foreach (var hv in danhSach)
        {
            if (hv is HoiVienCoNguoiYeu)
            {
                hv.Xuat();
                Console.WriteLine("--------------------");
            }
        }
    }
}
