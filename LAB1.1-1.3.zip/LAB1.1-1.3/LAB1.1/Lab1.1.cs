﻿////Bai 1
Console.OutputEncoding = System.Text.Encoding.UTF8; // Để hiển thị được tiếng việt
//string? ten;
//int tuoi;
//Console.WriteLine("Nhập tên : ");
//ten = Console.ReadLine();
//Console.WriteLine("Nhập tuổi : ");
//tuoi = int.Parse(Console.ReadLine() ?? "0");
//// Xuat ra
//Console.WriteLine($"Xin chào {ten}, bạn {tuoi} tuổi ");

////Bai 2
//double chieuDai, chieuRong, dienTich;
//try
//{
//    Console.WriteLine("Nhập chiều dài : ");
//    chieuDai = double.Parse(Console.ReadLine() ?? "0");
//    Console.WriteLine("Nhập chiều rộng : ");
//    chieuRong = double.Parse(Console.ReadLine() ?? "0");
//    if (chieuDai <= 0 || chieuRong <= 0)
//        throw new Exception("Chiều dài và chiều rộng phải lớn hơn 0");

//    //tính diện tích
//    dienTich = chieuDai * chieuRong;
//    Console.WriteLine($"Diện tích hình chữ nhật là : {dienTich}");

//}
//catch (FormatException ex)
//{
//    Console.WriteLine("Lỗi nhập liệu : " + ex.Message);
//}

//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi : " + ex.Message);
//}

//Bai 3
/*
double nhietdoC, nhietdoF;
try
{
    Console.WriteLine("Nhập nhiệt độ C : ");
    nhietdoC = double.Parse(Console.ReadLine() ?? "0");
    if (nhietdoC < -273.15)
        throw new Exception("Nhiệt độ không hợp lệ");
    //Chuyển đổi sang F
    nhietdoF = (9 * nhietdoC) / 5 + 32;
    Console.WriteLine($"Nhiệt độ F là : {nhietdoF}");
}
catch (FormatException ex)
{
    Console.WriteLine("Lỗi nhập liệu : " + ex.Message);
}

catch (Exception ex)
{
    Console.WriteLine("Lỗi : " + ex.Message);
}
*/
//Bai 4
/*
int a;
try
{
    Console.WriteLine("Nhập số nguyên : ");
    a = int.Parse(Console.ReadLine() ?? "0");
    if (a % 2 == 0)
    {
        Console.WriteLine($"{a} là số chẵn");
    }
    else
    {
        Console.WriteLine($"{a} là số lẻ");
    }
}
catch (FormatException)
{
    Console.WriteLine("Lỗi nhập liệu : Nhập số nguyên");
}

catch (Exception ex)
{
    Console.WriteLine("Lỗi : " + ex.Message);
}
*/
//Bai 5
/*
double a, b, tong , tich;
try
{
    Console.WriteLine("Nhập số a : ");
    a = double.Parse(Console.ReadLine() ?? "0");
    Console.WriteLine("Nhập số b : ");
    b = double.Parse(Console.ReadLine() ?? "0");
    //tính tổng
    tong = a + b;
    //tính tích
    tich = a * b;
    Console.WriteLine($"Tổng 2 số là : {tong}");
    Console.WriteLine($"Tích 2 số là : {tich}");
}
catch (FormatException ex)
{
    Console.WriteLine("Lỗi nhập liệu : " + ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine("Lỗi : " + ex.Message);
}
*/
//Bai 6
/*
int n;
try
{
    Console.WriteLine("Nhập số nguyên : ");
    n = int.Parse(Console.ReadLine() ?? "0");
    if (n > 0)
    {
        Console.WriteLine($"{n} là số dương");
    }
    else if (n < 0)
    {
        Console.WriteLine($"{n} là số âm");
    }
    else
    {
        Console.WriteLine($"{n} là số 0");
    }
}
catch (FormatException ex)
{
    Console.WriteLine("Lỗi nhập liệu : " + ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine("Lỗi : " + ex.Message);
}
*/
//Bai 7
//Bài 7: 
/*
int nam;
    Console.WriteLine("Nhập năm : ");
    nam = int.Parse(Console.ReadLine() ?? "0");
    if (nam % 4 == 0 && (nam % 100 != 0 || nam % 400 == 0))
    {
        Console.WriteLine($"{nam} là năm nhuận");
    }
    else if (nam <= 0)
    {
        Console.WriteLine("Năm không hợp lệ");
    }
    else
    {
        Console.WriteLine($"{nam} không phải là năm nhuận");
    }
*/
//Bai 8
/*
int n;
Console.WriteLine("Nhập số : ");
n = int.Parse(Console.ReadLine() ?? "0");
if (n < 1 || n > 10)
{
    Console.WriteLine("Số không hợp lệ");
}
else
{
    Console.WriteLine($"Bảng cửu chương {n} : ");
    for (int i = 1; i <= 10; i++)
    {
        Console.WriteLine($"{n} x {i} = {n * i}");
    }
}
*/
//Bai 9
/*  
int n;
Console.WriteLine("Nhập số nguyên dương n : ");
n = int.Parse(Console.ReadLine() ?? "0");
if (n < 0)
{
    Console.WriteLine("Số không hợp lệ");
}
else
{
    int giaiThua = 1;
    for (int i = 1; i <= n; i++)
    {
        giaiThua *= i;
    }
    Console.WriteLine($"Giai thừa của {n} là : {giaiThua}");
}
*/
////Bai 10
//int so;
//bool laSoNguyenTo = true;
//Console.WriteLine("Nhập số nguyên dương : ");
//so = int.Parse(Console.ReadLine() ?? "0");
//if (so < 2)
//{
//    Console.WriteLine($"{so} không phải là số nguyên tố");
//}
//else
//{
//    for (int i = 2; i <= Math.Sqrt(so); i++)
//    {
//        if (so % i == 0)
//        {
//            laSoNguyenTo = false;
//            break;
//        }
//    }
//    if (laSoNguyenTo)
//    {
//        Console.WriteLine($"{so} là số nguyên tố");
//    }
//    else
//    {
//        Console.WriteLine($"{so} không phải là số nguyên tố");
//    }
//}
