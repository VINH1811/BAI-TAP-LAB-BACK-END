﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        DanhSachThiSinh ds = new DanhSachThiSinh();

        while (true)
        {
            Console.WriteLine("\n========== MENU ==========");
            Console.WriteLine("1. Nhập danh sách thí sinh");
            Console.WriteLine("2. Hiển thị danh sách thí sinh");
            Console.WriteLine("3. Hiển thị thí sinh có tổng điểm > 15");
            Console.WriteLine("4. Sắp xếp danh sách theo tổng điểm giảm dần");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            int chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    Console.Write("Nhập số lượng thí sinh: ");
                    int n = int.Parse(Console.ReadLine());
                    ds.NhapDanhSach(n);
                    break;
                case 2:
                    ds.HienThiDanhSach();
                    break;
                case 3:
                    ds.TimThiSinhDiemLonHon15();
                    break;
                case 4:
                    ds.SapXepTheoTongDiemGiamDan();
                    break;
                case 0:
                    return;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }
        }
    }
}
