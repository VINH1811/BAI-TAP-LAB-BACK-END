﻿using System;

namespace LAB1._3Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            QuanLyTaiLieu quanLy = new QuanLyTaiLieu();
            quanLy.Menu();
        }
    }
}