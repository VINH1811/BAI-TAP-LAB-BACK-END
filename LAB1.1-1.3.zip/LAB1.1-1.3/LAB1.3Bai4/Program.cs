﻿using System;
using LAB1._3Bai4;

namespace LAB1._3Bai4
{
    class Program
    {
        static void Main(string[] args)
        {
            KhuPho khuPho = new KhuPho();
            khuPho.Menu();
        }
    }
}