﻿using System;
using System.Collections.Generic;
using LAB1._3Bai4;

namespace LAB1._3Bai4
{
    class HoDan
    {
        private int? soThanhVien;
        private string? soNha;
        private List<Nguoi> danhSachNguoi;

        public HoDan()
        {
            danhSachNguoi = new List<Nguoi>();
        }

        public HoDan(int soThanhVien, string soNha, List<Nguoi> danhSachNguoi)
        {
            this.soThanhVien = soThanhVien;
            this.soNha = soNha;
            this.danhSachNguoi = danhSachNguoi;
        }

        public void Nhap()
        {
            try
            {
                Console.WriteLine("Nhap so nha: ");
                soNha = Console.ReadLine();
                Console.WriteLine("Nhap so thanh vien trong ho: ");
                soThanhVien = int.Parse(Console.ReadLine() ?? "0");

                Console.WriteLine($"Nhap thong tin cho {soThanhVien} thanh vien:");
                for (int i = 0; i < soThanhVien; i++)
                {
                    Console.WriteLine($"\nThanh vien thu {i + 1}:");
                    Nguoi nguoi = new Nguoi();
                    nguoi.Nhap();
                    danhSachNguoi.Add(nguoi);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap lieu ho dan: " + ex.Message);
            }
        }

        public void HienThi()
        {
            Console.WriteLine($"So nha: {soNha}");
            Console.WriteLine($"So thanh vien: {soThanhVien}");
            Console.WriteLine("Danh sach thanh vien:");
            for (int i = 0; i < danhSachNguoi.Count; i++)
            {
                Console.WriteLine($"\nThanh vien thu {i + 1}:");
                danhSachNguoi[i].HienThi();
            }
        }

        public string SoNha => soNha;

        public bool ContainsHoTen(string ten)
        {
            foreach (var nguoi in danhSachNguoi)
            {
                if (nguoi.HoTen != null && nguoi.HoTen.ToLower().Contains(ten.ToLower()))
                    return true;
            }
            return false;
        }
    }
}
