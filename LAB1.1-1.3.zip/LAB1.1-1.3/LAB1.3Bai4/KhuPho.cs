﻿using System;
using System.Collections.Generic;
using LAB1._3Bai4;

namespace LAB1._3Bai4
{
    class KhuPho
    {
        private List<HoDan> danhSachHoDan = new List<HoDan>();

        public void Menu()
        {
            while (true)
            {
                Console.WriteLine("\n=== QUAN LY KHU PHO ===");
                Console.WriteLine("1. Nhap thong tin cac ho dan");
                Console.WriteLine("2. Tim kiem theo ho ten");
                Console.WriteLine("3. Tim kiem theo so nha");
                Console.WriteLine("4. Hien thi thong tin tat ca ho dan");
                Console.WriteLine("5. Thoat chuong trinh");
                Console.Write("Chon chuc nang (1-5): ");
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        NhapDanhSachHoDan();
                        break;
                    case "2":
                        TimKiemTheoHoTen();
                        break;
                    case "3":
                        TimKiemTheoSoNha();
                        break;
                    case "4":
                        HienThiTatCa();
                        break;
                    case "5":
                        Console.WriteLine("Thoat chuong trinh.");
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le! Vui long chon lai.");
                        break;
                }
            }
        }

        private void NhapDanhSachHoDan()
        {
            Console.Write("\nNhap so luong ho dan: ");
            int n;
            try
            {
                n = int.Parse(Console.ReadLine() ?? "0");
                if (n <= 0) throw new Exception("So luong ho dan phai lon hon 0!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi: " + ex.Message);
                return;
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nNhap thong tin ho dan thu {i + 1}:");
                HoDan hoDan = new HoDan();
                try
                {
                    hoDan.Nhap();
                    danhSachHoDan.Add(hoDan);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.WriteLine("Da nhap xong danh sach ho dan!");
        }

        private void TimKiemTheoHoTen()
        {
            Console.Write("\nNhap ho ten can tim: ");
            string? ten = Console.ReadLine();

            bool found = false;
            Console.WriteLine("\n=== KET QUA TIM KIEM THEO HO TEN ===");
            foreach (var hoDan in danhSachHoDan)
            {
                if (hoDan.ContainsHoTen(ten))
                {
                    Console.WriteLine("------------------------");
                    hoDan.HienThi();
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong tim thay ho dan voi ten nay!");
            }
            Console.WriteLine("------------------------");
        }

        private void TimKiemTheoSoNha()
        {
            Console.Write("\nNhap so nha can tim: ");
            string? soNha = Console.ReadLine();

            bool found = false;
            Console.WriteLine("\n=== KET QUA TIM KIEM THEO SO NHA ===");
            foreach (var hoDan in danhSachHoDan)
            {
                if (hoDan.SoNha == soNha)
                {
                    Console.WriteLine("------------------------");
                    hoDan.HienThi();
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong tim thay ho dan voi so nha nay!");
            }
            Console.WriteLine("------------------------");
        }

        private void HienThiTatCa()
        {
            if (danhSachHoDan.Count == 0)
            {
                Console.WriteLine("Danh sach ho dan trong!");
                return;
            }

            Console.WriteLine("\n=== DANH SACH TAT CA HO DAN ===");
            foreach (var hoDan in danhSachHoDan)
            {
                Console.WriteLine("------------------------");
                hoDan.HienThi();
            }
            Console.WriteLine("------------------------");
        }
    }
}