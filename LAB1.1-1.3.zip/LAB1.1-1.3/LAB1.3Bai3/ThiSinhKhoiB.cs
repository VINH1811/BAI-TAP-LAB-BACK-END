﻿using System;
using LAB1._3Bai3;

namespace LAB1._3Bai3
{
    class ThiSinhKhoiB : ThiSinh
    {
        private double? diemToan;
        private double? diemHoa;
        private double? diemSinh;

        public ThiSinhKhoiB() { }

        public ThiSinhKhoiB(string soBaoDanh, string hoTen, string diaChi, int uuTien,
            double diemToan, double diemHoa, double diemSinh)
            : base(soBaoDanh, hoTen, diaChi, uuTien)
        {
            this.diemToan = diemToan;
            this.diemHoa = diemHoa;
            this.diemSinh = diemSinh;
        }

        public override void Nhap()
        {
            base.Nhap();
            try
            {
                Console.WriteLine("Nhap diem Toan: ");
                diemToan = double.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap diem Hoa: ");
                diemHoa = double.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap diem Sinh: ");
                diemSinh = double.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap diem: " + ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Diem Toan: {diemToan}");
            Console.WriteLine($"Diem Hoa: {diemHoa}");
            Console.WriteLine($"Diem Sinh: {diemSinh}");
            Console.WriteLine($"Tong diem: {TinhTongDiem()}");
        }

        public override double TinhTongDiem()
        {
            return (diemToan ?? 0) + (diemHoa ?? 0) + (diemSinh ?? 0) + (uuTien ?? 0);
        }
    }
}