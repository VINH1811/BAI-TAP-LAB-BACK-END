﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QLTamGiac
{
    private List<TamGiac> danhSach = new List<TamGiac>();

    public void NhapDS()
    {
        Console.Write("Nhập số lượng tam giác: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\n== Nhập tam giác thứ {i + 1} ==");
            TamGiac tg = new TamGiac();
            tg.Nhap();
            danhSach.Add(tg);
        }
    }

    public void HienThiDS()
    {
        Console.WriteLine("\n== DANH SÁCH TAM GIÁC ==");
        int i = 1;
        foreach (var tg in danhSach)
        {
            Console.WriteLine($"\nTam giác {i++}:");
            tg.HienThi();
            Console.WriteLine($"Chu vi: {tg.TinhChuVi():F2}");
            Console.WriteLine($"Diện tích: {tg.TinhDienTich():F2}");
        }
    }

    public void TinhTongChuViVaDienTich()
    {
        double tongCV = 0, tongDT = 0;
        foreach (var tg in danhSach)
        {
            tongCV += tg.TinhChuVi();
            tongDT += tg.TinhDienTich();
        }

        Console.WriteLine($"\nTổng chu vi của tất cả tam giác: {tongCV:F2}");
        Console.WriteLine($"Tổng diện tích của tất cả tam giác: {tongDT:F2}");
    }
}
