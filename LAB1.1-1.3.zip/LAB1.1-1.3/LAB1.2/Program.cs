﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
//// Bài 1: Viết một hàm để tính tổng của tất cả các số chẵn trong một mảng.
//static int TinhTongSoChan(int[] arr)
//{
//    int tong = 0;
//    foreach (int num in arr)
//    {
//        if (num % 2 == 0)
//            tong += num;
//    }
//    return tong;
//}
//try
//{
//    Console.Write("Nhập số phần tử của mảng: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    int[] arr = new int[n];
//    for (int i = 0; i < n; i++)
//    {
//        Console.Write($"Nhập phần tử thứ {i}: ");
//        arr[i] = int.Parse(Console.ReadLine() ?? "0");
//    }
//    int tongChan = TinhTongSoChan(arr);
//    Console.WriteLine($"Tổng các số chẵn: {tongChan}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}

//// Bài 2: Viết chương trình nhập vào mảng gồm n phần tử nhập từ bàn phím. Viết hàm để kiểm
////tra xem một số có phải là số nguyên tố hay không, hiển thị chỉ số và giá trị của những phần tử
////là số nguyên tố trong mảng.
//static bool LaSoNguyenTo(int n)
//{
//    if (n < 2) return false;
//    for (int i = 2; i <= Math.Sqrt(n); i++)
//    {
//        if (n % i == 0) return false;
//    }
//    return true;
//}
//try
//{
//    Console.Write("Nhập số phần tử của mảng: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    int[] arr = new int[n];
//    for (int i = 0; i < n; i++)
//    {
//        Console.Write($"Nhập phần tử thứ {i}: ");
//        arr[i] = int.Parse(Console.ReadLine() ?? "0");
//    }
//    Console.WriteLine("Các số nguyên tố trong mảng:");
//    for (int i = 0; i < n; i++)
//    {
//        if (LaSoNguyenTo(arr[i]))
//            Console.WriteLine($"Chỉ số {i}: {arr[i]}");
//    }
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}

//// Bài 3: Viết một hàm để đếm số lượng số âm và số dương trong một mảng gồm n phần tử nhập
////từ bàn phím.
//static void DemSoAmDuong(double[] arr, out int soAm, out int soDuong)
//{
//    soAm = 0;
//    soDuong = 0;
//    foreach (double num in arr)
//    {
//        if (num > 0) soDuong++;
//        else if (num < 0) soAm++;
//    }
//}

//try
//{
//    Console.Write("Nhập số phần tử của mảng: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    double[] arr = new double[n];
//    for (int i = 0; i < n; i++)
//    {
//        Console.Write($"Nhập phần tử thứ {i}: ");
//        arr[i] = double.Parse(Console.ReadLine() ?? "0");
//    }
//    int soAm, soDuong;
//    DemSoAmDuong(arr, out soAm, out soDuong);
//    Console.WriteLine($"Số lượng số âm: {soAm}");
//    Console.WriteLine($"Số lượng số dương: {soDuong}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}

//// Bài 4: Viết hàm để tìm số lớn thứ hai trong một mảng các số nguyên
//static int TimSoLonThuHai(int[] arr)
//{
//    if (arr.Length < 2) return -1; 
//    int max = int.MinValue;
//    int max2 = int.MinValue;
//    foreach (int num in arr)
//    {
//        if (num > max)
//        {
//            max2 = max;
//            max = num;
//        }
//        else if (num > max2 && num != max)
//        {
//            max2 = num;
//        }
//    }
//    return max2 == int.MinValue ? -1 : max2; 
//}

//try
//{
//    Console.Write("Nhập số phần tử của mảng: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    int[] arr = new int[n];
//    for (int i = 0; i < n; i++)
//    {
//        Console.Write($"Nhập phần tử thứ {i}: ");
//        arr[i] = int.Parse(Console.ReadLine() ?? "0");
//    }
//    int max2 = TimSoLonThuHai(arr);
//    if (max2 == -1)
//        Console.WriteLine("Không tìm thấy số lớn thứ hai.");
//    else
//        Console.WriteLine($"Số lớn thứ hai: {max2}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}

////Bài 5: Viết hàm hoán vị 2 số nguyên a và b nhập từ bàn phím
//static void HoanVi(ref int a, ref int b)
//{
//    int temp = a;
//    a = b;
//    b = temp;
//}

//try
//{
//    Console.Write("Nhập số a: ");
//    int a = int.Parse(Console.ReadLine() ?? "0");
//    Console.Write("Nhập số b: ");
//    int b = int.Parse(Console.ReadLine() ?? "0");
//    Console.WriteLine($"Trước khi hoán vị: a = {a}, b = {b}");
//    HoanVi(ref a, ref b);
//    Console.WriteLine($"Sau khi hoán vị: a = {a}, b = {b}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}

// Bài 6: Viết hàm sắp xếp mảng số thực n phần tử nhập từ bàn phím theo chiều tăng dần.
//static void SapXepTangDan(double[] arr)
//{
//    Array.Sort(arr);
//}

//try
//{
//    Console.Write("Nhập số phần tử của mảng: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    double[] arr = new double[n];
//    for (int i = 0; i < n; i++)
//    {
//        Console.Write($"Nhập phần tử thứ {i}: ");
//        arr[i] = double.Parse(Console.ReadLine() ?? "0");
//    }
//    Console.WriteLine("Mảng trước khi sắp xếp:");
//    Console.WriteLine(string.Join(" ", arr));
//    SapXepTangDan(arr);
//    Console.WriteLine("Mảng sau khi sắp xếp tăng dần:");
//    Console.WriteLine(string.Join(" ", arr));
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}