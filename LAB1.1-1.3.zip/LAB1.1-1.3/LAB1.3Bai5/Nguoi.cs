﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Nguoi
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string CMND { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Nhập họ tên: ");
        HoTen = Console.ReadLine();

        Console.Write("Nhập năm sinh: ");
        NamSinh = int.Parse(Console.ReadLine());

        Console.Write("Nhập CMND: ");
        CMND = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Họ tên: {HoTen}, Năm sinh: {NamSinh}, CMND: {CMND}");
    }
}

