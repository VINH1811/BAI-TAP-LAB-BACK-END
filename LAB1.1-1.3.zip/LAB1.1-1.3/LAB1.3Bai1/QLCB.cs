﻿using System;
using System.Collections.Generic;

namespace LAB1._3Bai1
    class QLCB
    {
        private List<CanBo> danhSachCanBo = new List<CanBo>();

        public void Menu()
        {
            while (true)
            {
                Console.WriteLine("\n=== QUAN LY CAN BO ===");
                Console.WriteLine("1. Nhap thong tin can bo");
                Console.WriteLine("2. Tim kiem theo ho ten");
                Console.WriteLine("3. Hien thi danh sach can bo");
                Console.WriteLine("4. Thoat chuong trinh");
                Console.Write("Chon chuc nang (1-4): ");
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        NhapCanBo();
                        break;
                    case "2":
                        TimKiemTheoHoTen();
                        break;
                    case "3":
                        HienThiDanhSach();
                        break;
                    case "4":
                        Console.WriteLine("Thoat chuong trinh.");
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le! Vui long chon lai.");
                        break;
                }
            }
        }

        private void NhapCanBo()
        {
            Console.WriteLine("\nChon loai can bo muon nhap:");
            Console.WriteLine("1. Cong nhan");
            Console.WriteLine("2. Ky su");
            Console.WriteLine("3. Nhan vien");
            Console.Write("Nhap lua chon (1-3): ");
            string? loai = Console.ReadLine();

            CanBo canBo = null;
            switch (loai)
            {
                case "1":
                    canBo = new CongNhan();
                    break;
                case "2":
                    canBo = new KySu();
                    break;
                case "3":
                    canBo = new NhanVien();
                    break;
                default:
                    Console.WriteLine("Loai can bo khong hop le!");
                    return;
            }

            try
            {
                canBo.Nhap();
                danhSachCanBo.Add(canBo);
                Console.WriteLine("Da them can bo thanh cong!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void TimKiemTheoHoTen()
        {
            Console.Write("\nNhap ho ten can tim: ");
            string? ten = Console.ReadLine();

            bool found = false;
            Console.WriteLine("\n=== KET QUA TIM KIEM ===");
            foreach (var canBo in danhSachCanBo)
            {
                if (canBo.HoTen != null && canBo.HoTen.ToLower().Contains(ten.ToLower()))
                {
                    Console.WriteLine("------------------------");
                    canBo.HienThi();
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong tim thay can bo voi ten nay!");
            }
            Console.WriteLine("------------------------");
        }

        private void HienThiDanhSach()
        {
            if (danhSachCanBo.Count == 0)
            {
                Console.WriteLine("Danh sach can bo trong!");
                return;
            }

            Console.WriteLine("\n=== DANH SACH CAN BO ===");
            foreach (var canBo in danhSachCanBo)
            {
                Console.WriteLine("------------------------");
                canBo.HienThi();
            }
            Console.WriteLine("------------------------");
        }
    }
}