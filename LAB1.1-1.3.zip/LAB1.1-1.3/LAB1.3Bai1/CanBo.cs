﻿using System;

namespace LAB1._3Bai1
{
    abstract class CanBo
    {
        protected string? hoTen;
        protected int? namSinh;
        protected string? gioiTinh;
        protected string? diaChi;

        public CanBo() { }

        public CanBo(string hoTen, int namSinh, string gioiTinh, string diaChi)
        {
            this.hoTen = hoTen;
            this.namSinh = namSinh;
            this.gioiTinh = gioiTinh;
            this.diaChi = diaChi;
        }

        public virtual void Nhap()
        {
            try
            {
                Console.WriteLine("Nhap ho ten: ");
                hoTen = Console.ReadLine();
                Console.WriteLine("Nhap nam sinh: ");
                namSinh = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap gioi tinh (Nam/Nu): ");
                gioiTinh = Console.ReadLine();
                Console.WriteLine("Nhap dia chi: ");
                diaChi = Console.ReadLine();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap lieu: " + ex.Message);
            }
        }

        public virtual void HienThi()
        {
            Console.WriteLine($"Ho ten: {hoTen}");
            Console.WriteLine($"Nam sinh: {namSinh}");
            Console.WriteLine($"Gioi tinh: {gioiTinh}");
            Console.WriteLine($"Dia chi: {diaChi}");
        }

        public string HoTen => hoTen;
    }
}