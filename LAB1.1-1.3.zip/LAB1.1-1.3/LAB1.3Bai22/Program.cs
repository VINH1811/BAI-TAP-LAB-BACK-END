﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLHocSinh qlhs = new QLHocSinh();

        while (true)
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Nhập danh sách học sinh");
            Console.WriteLine("2. Sắp xếp và hiển thị danh sách");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            string chon = Console.ReadLine();

            switch (chon)
            {
                case "1":
                    qlhs.Nhap();
                    break;
                case "2":
                    qlhs.SapXepVaHienThi();
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Chọn không hợp lệ!");
                    break;
            }
        }
    }
}
