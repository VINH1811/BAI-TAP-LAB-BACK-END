﻿using LAB03_NVV.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB03_NVV.Controllers
{
    public class UserController : Controller
    {
        static List<User> users = new List<User>()
        {
        new User() {id="1",username="aaa",password="1",phone="111",email="111"},
        new User() {id="1",username="aaa",password="1",phone="111",email="111"},
        new User() {id="1",username="aaa",password="1",phone="111",email="111"},
        new User() {id="1",username="aaa",password="1",phone="111",email="111"},
        new User() {id="1",username="aaa",password="1",phone="111",email="111"},
        };
        public IActionResult Index()
        {
            return View(users);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(User user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users.Add(user);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);

            }
            return View(user);
        }
        [HttpGet]
        public IActionResult Edit(string id = null)
        {
            Console.WriteLine($"Received id: {id ?? "null"}");
            if (string.IsNullOrEmpty(id))
            {
                return RedirectToAction("Index");
            }

            var user = users.FirstOrDefault(u => u.id == id);
            if (user == null)
            {
                Console.WriteLine("User not found!");
                return NotFound();
            }
            Console.WriteLine($"Found user: ID={user.id}, Username={user.username}");
            return View(user);
        }
        [HttpPost]
        public IActionResult Edit(User user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (users.Any(u => u.username == user.username && u.id != user.id))
                    {
                        ModelState.AddModelError("username", "Tài khoản đã tồn tại!");
                        return View(user);
                    }

                    if (users.Any(u => u.email == user.email && u.id != user.id))
                    {
                        ModelState.AddModelError("email", "Email đã tồn tại!");
                        return View(user);
                    }

                    var existingUser = users.FirstOrDefault(u => u.id == user.id);
                    if (existingUser == null)
                    {
                        return NotFound();
                    }

                    existingUser.username = user.username;
                    existingUser.password = user.password;
                    existingUser.email = user.email;
                    existingUser.phone = user.phone;

                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
            return View(user);
        }
    }

}
