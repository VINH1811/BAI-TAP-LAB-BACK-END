﻿using System;

namespace Lab1._5_Bai2
{
    class HinhVuong : Hinh
    {
        private double canh;
        public double Canh
        {
            get => canh;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Cạnh phải lớn hơn 0!");
                canh = value;
            }
        }
        public override void Nhap()
        {
            bool validInput;
            do
            {
                Console.Write("Nhập cạnh: ");
                string input = Console.ReadLine() ?? "0";
                validInput = double.TryParse(input, out canh);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Cạnh không được để trống!");
                    else
                        Console.WriteLine("Cạnh phải là số!");
                }
                else if (canh <= 0)
                {
                    Console.WriteLine("Cạnh phải lớn hơn 0!");
                    validInput = false;
                }
            } while (!validInput);
        }
        public override double TinhChuVi() => 4 * canh;
        public override double TinhDienTich() => canh * canh;

        public override string ToString()
        {
            return $"Hình vuông: cạnh = {canh:F2}, chu vi = {TinhChuVi():F2}, diện tích = {TinhDienTich():F2}";
        }
    }
}