﻿using System;

namespace Lab1._5_Bai2
{
    class HinhChuNhat : Hinh
    {
        private double dai, rong;
        public double Dai
        {
            get => dai;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Chiều dài phải lớn hơn 0!");
                dai = value;
            }
        }

        public double Rong
        {
            get => rong;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Chiều rộng phải lớn hơn 0!");
                rong = value;
            }
        }

        public override void Nhap()
        {
            bool validInput;
            do
            {
                Console.Write("Nhập chiều dài: ");
                string input = Console.ReadLine() ?? "0";
                validInput = double.TryParse(input, out dai);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Chiều dài không được để trống!");
                    else
                        Console.WriteLine("Chiều dài phải là số!");
                }
                else if (dai <= 0)
                {
                    Console.WriteLine("Chiều dài phải lớn hơn 0!");
                    validInput = false;
                }
            } while (!validInput);

            do
            {
                Console.Write("Nhập chiều rộng: ");
                string input = Console.ReadLine() ?? "0";
                validInput = double.TryParse(input, out rong);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Chiều rộng không được để trống!");
                    else
                        Console.WriteLine("Chiều rộng phải là số!");
                }
                else if (rong <= 0)
                {
                    Console.WriteLine("Chiều rộng phải lớn hơn 0!");
                    validInput = false;
                }
            } while (!validInput);
        }

        public override double TinhChuVi() => 2 * (dai + rong);
        public override double TinhDienTich() => dai * rong;

        public override string ToString()
        {
            return $"Hình chữ nhật: dài = {dai:F2}, rộng = {rong:F2}, chu vi = {TinhChuVi():F2}, diện tích = {TinhDienTich():F2}";
        }
    }
}