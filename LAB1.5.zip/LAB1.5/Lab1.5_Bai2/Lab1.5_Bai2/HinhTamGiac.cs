﻿using System;

namespace Lab1._5_Bai2
{
    class HinhTamGiac : Hinh
    {
        private double a, b, c;
        public double A
        {
            get => a;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Cạnh a phải lớn hơn 0!");
                a = value;
            }
        }
        public double B
        {
            get => b;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Cạnh b phải lớn hơn 0!");
                b = value;
            }
        }
        public double C
        {
            get => c;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Cạnh c phải lớn hơn 0!");
                c = value;
            }
        }

        public override void Nhap()
        {
            bool validInput;
            do
            {
                do
                {
                    Console.Write("Nhập cạnh a: ");
                    string input = Console.ReadLine() ?? "0";
                    validInput = double.TryParse(input, out a);
                    if (!validInput)
                    {
                        if (string.IsNullOrEmpty(input))
                            Console.WriteLine("Cạnh a không được để trống!");
                        else
                            Console.WriteLine("Cạnh a phải là số!");
                    }
                    else if (a <= 0)
                    {
                        Console.WriteLine("Cạnh a phải lớn hơn 0!");
                        validInput = false;
                    }
                } while (!validInput);

                do
                {
                    Console.Write("Nhập cạnh b: ");
                    string input = Console.ReadLine() ?? "0";
                    validInput = double.TryParse(input, out b);
                    if (!validInput)
                    {
                        if (string.IsNullOrEmpty(input))
                            Console.WriteLine("Cạnh b không được để trống!");
                        else
                            Console.WriteLine("Cạnh b phải là số!");
                    }
                    else if (b <= 0)
                    {
                        Console.WriteLine("Cạnh b phải lớn hơn 0!");
                        validInput = false;
                    }
                } while (!validInput);

                do
                {
                    Console.Write("Nhập cạnh c: ");
                    string input = Console.ReadLine() ?? "0";
                    validInput = double.TryParse(input, out c);
                    if (!validInput)
                    {
                        if (string.IsNullOrEmpty(input))
                            Console.WriteLine("Cạnh c không được để trống!");
                        else
                            Console.WriteLine("Cạnh c phải là số!");
                    }
                    else if (c <= 0)
                    {
                        Console.WriteLine("Cạnh c phải lớn hơn 0!");
                        validInput = false;
                    }
                } while (!validInput);

                // Kiểm tra điều kiện tam giác
                if (a + b <= c || b + c <= a || a + c <= b)
                {
                    Console.WriteLine("Ba cạnh không tạo thành tam giác! Vui lòng nhập lại.");
                    validInput = false;
                }
                else
                {
                    validInput = true;
                }
            } while (!validInput);
        }
        public override double TinhChuVi() => a + b + c;

        public override double TinhDienTich()
        {
            double p = TinhChuVi() / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
        }

        public override string ToString()
        {
            return $"Hình tam giác: a = {a:F2}, b = {b:F2}, c = {c:F2}, chu vi = {TinhChuVi():F2}, diện tích = {TinhDienTich():F2}";
        }
    }
}