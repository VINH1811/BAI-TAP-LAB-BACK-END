﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1._5_Bai2
{
    class Program
    {
        public static List<Hinh> danhSachHinh = new List<Hinh>();
        static Program()
        {
            HinhTron hinhTron = new HinhTron();
            hinhTron.BanKinh = 3;
            danhSachHinh.Add(hinhTron);
            HinhVuong hinhVuong = new HinhVuong();
            hinhVuong.Canh = 4;
            danhSachHinh.Add(hinhVuong);
            HinhTamGiac hinhTamGiac = new HinhTamGiac();
            hinhTamGiac.A = 3;
            hinhTamGiac.B = 4;
            hinhTamGiac.C = 5;
            danhSachHinh.Add(hinhTamGiac);
            HinhChuNhat hinhChuNhat = new HinhChuNhat();
            hinhChuNhat.Dai = 5;
            hinhChuNhat.Rong = 3;
            danhSachHinh.Add(hinhChuNhat);
        }
        public static bool AddHinh(Hinh hinh)
        {
            try
            {
                danhSachHinh.Add(hinh);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public static bool EditHinh(int index, Hinh hinh)
        {
            try
            {
                if (index >= 0 && index < danhSachHinh.Count)
                {
                    danhSachHinh[index] = hinh;
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool DeleteHinh(int index)
        {
            try
            {
                if (index >= 0 && index < danhSachHinh.Count)
                {
                    danhSachHinh.RemoveAt(index);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        public static void GetHinhs()
        {
            Console.WriteLine("STT\tTHÔNG TIN HÌNH");
            for (int i = 0; i < danhSachHinh.Count; i++)
            {
                Console.WriteLine($"{i}\t{danhSachHinh[i]}");
            }
            if (danhSachHinh.Count > 0)
            {
                double tongChuVi = 0, tongDienTich = 0;
                foreach (var hinh in danhSachHinh)
                {
                    tongChuVi += hinh.TinhChuVi();
                    tongDienTich += hinh.TinhDienTich();
                }
                Console.WriteLine($"\nTổng chu vi: {tongChuVi:F2}");
                Console.WriteLine($"Tổng diện tích: {tongDienTich:F2}");
            }
            else
            {
                Console.WriteLine("\nDanh sách rỗng!");
            }
        }
        public static void Alert(bool isSuccess, string action)
        {
            string message = isSuccess ? $"{action} thành công!" : $"{action} thất bại!";
            Console.WriteLine(message);
            Console.WriteLine("Nhấn phím bất kỳ để tiếp tục...");
            Console.ReadLine();
        }
        public static Hinh NhapLoaiHinh()
        {
            int loai;
            bool validInput;
            do
            {
                Console.Write("Chọn loại (1-Tròn, 2-Vuông, 3-Tam giác, 4-Chữ nhật): ");
                string input = Console.ReadLine() ?? "0";
                validInput = int.TryParse(input, out loai);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Lựa chọn không được để trống!");
                    else
                        Console.WriteLine("Lựa chọn phải là số!");
                }
                else if (loai < 1 || loai > 4)
                {
                    Console.WriteLine("Vui lòng chọn từ 1 đến 4!");
                    validInput = false;
                }
            } while (!validInput);

            Hinh hinh = loai switch
            {
                1 => new HinhTron(),
                2 => new HinhVuong(),
                3 => new HinhTamGiac(),
                4 => new HinhChuNhat(),
                _ => null
            };

            return hinh;
        }
        public static void GetMenu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("-----------------------Quản lý hình học-----------------------");
                GetHinhs();
                Console.WriteLine("-------------------------------------------------------------");
                Console.WriteLine("\t1. Thêm hình");
                Console.WriteLine("\t2. Sửa hình");
                Console.WriteLine("\t3. Xóa hình");
                Console.WriteLine("\t4. Thoát");
                do
                {
                    try
                    {
                        Console.Write("- Mời bạn chọn chức năng: ");
                        choice = int.Parse(Console.ReadLine() ?? "0");
                        if (choice < 1 || choice > 4)
                            Console.WriteLine("Vui lòng chọn từ 1 đến 4!");
                        else
                            break;
                    }
                    catch
                    {
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                    }
                } while (true);

                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("- Nhập thông tin hình mới:");
                            Hinh hinh = NhapLoaiHinh();
                            if (hinh != null)
                            {
                                hinh.Nhap();
                                Alert(AddHinh(hinh), "Thêm");
                            }
                            else
                            {
                                Alert(false, "Thêm");
                            }
                        }
                        break;

                    case 2:
                        {
                            Console.Write("- Nhập số thứ tự (STT) hình muốn sửa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine() ?? "0");
                                if (index >= 0 && index < danhSachHinh.Count)
                                {
                                    Console.WriteLine("- Nhập thông tin mới:");
                                    Hinh hinh = NhapLoaiHinh();
                                    if (hinh != null)
                                    {
                                        hinh.Nhap();
                                        Alert(EditHinh(index, hinh), "Sửa");
                                    }
                                    else
                                    {
                                        Alert(false, "Sửa");
                                    }
                                }
                                else
                                {
                                    Alert(false, "Sửa");
                                }
                            }
                            catch
                            {
                                Alert(false, "Sửa");
                            }
                        }
                        break;

                    case 3:
                        {
                            Console.Write("- Nhập số thứ tự (STT) hình muốn xóa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine() ?? "0");
                                Alert(DeleteHinh(index), "Xóa");
                            }
                            catch
                            {
                                Alert(false, "Xóa");
                            }
                        }
                        break;

                    default:
                        break;
                }
            } while (choice != 4);
        }
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8; 
            GetMenu();
        }
    }
}