﻿using System;

namespace Lab1._5_Bai2
{
    class HinhTron : Hinh
    {
        private double banKinh;
        public double BanKinh
        {
            get => banKinh;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Bán kính phải lớn hơn 0!");
                banKinh = value;
            }
        }
        public override void Nhap()
        {
            bool validInput;
            do
            {
                Console.Write("Nhập bán kính: ");
                string input = Console.ReadLine() ?? "0";
                validInput = double.TryParse(input, out banKinh);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Bán kính không được để trống!");
                    else
                        Console.WriteLine("Bán kính phải là số!");
                }
                else if (banKinh <= 0)
                {
                    Console.WriteLine("Bán kính phải lớn hơn 0!");
                    validInput = false;
                }
            } while (!validInput);
        }
        public override double TinhChuVi() => 2 * Math.PI * banKinh;
        public override double TinhDienTich() => Math.PI * banKinh * banKinh;
        public override string ToString()
        {
            return $"Hình tròn: bán kính = {banKinh:F2}, chu vi = {TinhChuVi():F2}, diện tích = {TinhDienTich():F2}";
        }
    }
}