﻿using System;

namespace Lab1._5_Bai1
{
    public class PhanSo
    {
        public int TuSo { get; set; }
        public int MauSo { get; set; }
        public PhanSo() {}
        public PhanSo(int tuSo, int mauSo)
        {
            if (mauSo == 0)
                throw new ArgumentException("Mẫu số không được bằng 0");
            TuSo = tuSo;
            MauSo = mauSo;
            RutGon();
        }

        // Nhập phân số
        public void NhapPhanSo()
        {
            bool validInput;
            do
            {
                try
                {
                    Console.Write("Nhập tử số: ");
                    TuSo = int.Parse(Console.ReadLine());
                    validInput = true;
                }
                catch
                {
                    Console.WriteLine("Tử số phải là số nguyên!");
                    validInput = false;
                }
            } while (!validInput);

            do
            {
                try
                {
                    Console.Write("Nhập mẫu số (khác 0): ");
                    MauSo = int.Parse(Console.ReadLine());
                    if (MauSo == 0)
                    {
                        Console.WriteLine("Mẫu số không được bằng 0!");
                        validInput = false;
                    }
                    else
                    {
                        validInput = true;
                    }
                }
                catch
                {
                    Console.WriteLine("Mẫu số phải là số nguyên!");
                    validInput = false;
                }
            } while (!validInput);

            RutGon();
        }

        // Tìm ước chung lớn nhất (UCLN)
        private int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        // Rút gọn phân số
        private void RutGon()
        {
            int ucln = UCLN(TuSo, MauSo);
            TuSo /= ucln;
            MauSo /= ucln;
            if (MauSo < 0)
            {
                TuSo = -TuSo;
                MauSo = -MauSo;
            }
        }

        // Cộng hai phân số
        public static PhanSo Cong(PhanSo ps1, PhanSo ps2)
        {
            int tu = ps1.TuSo * ps2.MauSo + ps2.TuSo * ps1.MauSo;
            int mau = ps1.MauSo * ps2.MauSo;
            return new PhanSo(tu, mau);
        }

        // Hiển thị phân số
        public override string ToString()
        {
            if (MauSo == 1)
                return TuSo.ToString();
            if (TuSo == 0)
                return "0";
            return $"{TuSo}/{MauSo}";
        }
    }
}