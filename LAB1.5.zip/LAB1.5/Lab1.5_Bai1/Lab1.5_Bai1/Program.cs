﻿using System;
using System.Collections.Generic;
using System.Text;
using Lab1._5_Bai1;

namespace Lab1._5_Bai1
{
    class Program
    {
        public static List<PhanSo> danhSachPhanSo = new List<PhanSo>()
        {
            new PhanSo(1, 2), 
            new PhanSo(1, 3), 
            new PhanSo(1, 6), 
            new PhanSo(2, 5), 
            new PhanSo(3, 4)  
        };
        public static bool AddPhanSo(PhanSo phanSo)
        {
            try
            {
                danhSachPhanSo.Add(phanSo);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool EditPhanSo(int index, PhanSo phanSo)
        {
            try
            {
                if (index >= 0 && index < danhSachPhanSo.Count)
                {
                    danhSachPhanSo[index] = phanSo;
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool DeletePhanSo(int index)
        {
            try
            {
                if (index >= 0 && index < danhSachPhanSo.Count)
                {
                    danhSachPhanSo.RemoveAt(index);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        public static void GetPhanSos()
        {
            Console.WriteLine("STT\tPHÂN SỐ");
            for (int i = 0; i < danhSachPhanSo.Count; i++)
            {
                Console.WriteLine($"{i}\t{danhSachPhanSo[i]}");
            }
            if (danhSachPhanSo.Count > 0)
            {
                PhanSo tong = danhSachPhanSo[0];
                for (int i = 1; i < danhSachPhanSo.Count; i++)
                {
                    tong = PhanSo.Cong(tong, danhSachPhanSo[i]);
                }
                Console.WriteLine($"\nTổng các phân số: {tong}");
            }
            else
            {
                Console.WriteLine("\nDanh sách rỗng!");
            }
        }
        public static void Alert(bool isSuccess, string action)
        {
            string message = isSuccess ? $"{action} thành công!" : $"{action} thất bại!";
            Console.WriteLine(message);
            Console.WriteLine("Nhấn phím bất kỳ để tiếp tục...");
            Console.ReadLine();
        }
        public static void GetMenu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("-----------------------Quản lý phân số-----------------------");
                GetPhanSos();
                Console.WriteLine("-------------------------------------------------------------");
                Console.WriteLine("\t1. Thêm phân số");
                Console.WriteLine("\t2. Sửa phân số");
                Console.WriteLine("\t3. Xóa phân số");
                Console.WriteLine("\t4. Thoát");
                do
                {
                    try
                    {
                        Console.Write("- Mời bạn chọn chức năng: ");
                        choice = int.Parse(Console.ReadLine());
                        if (choice < 1 || choice > 4)
                            Console.WriteLine("Vui lòng chọn từ 1 đến 4!");
                        else
                            break;
                    }
                    catch
                    {
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                    }
                } while (true);

                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("- Nhập phân số mới:");
                            PhanSo phanSo = new PhanSo();
                            phanSo.NhapPhanSo();
                            Alert(AddPhanSo(phanSo), "Thêm");
                        }
                        break;

                    case 2:
                        {
                            Console.Write("- Nhập số thứ tự (STT) phân số muốn sửa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine());
                                if (index >= 0 && index < danhSachPhanSo.Count)
                                {
                                    Console.WriteLine("- Nhập thông tin mới:");
                                    PhanSo phanSo = new PhanSo();
                                    phanSo.NhapPhanSo();
                                    Alert(EditPhanSo(index, phanSo), "Sửa");
                                }
                                else
                                {
                                    Alert(false, "Sửa");
                                }
                            }
                            catch
                            {
                                Alert(false, "Sửa");
                            }
                        }
                        break;

                    case 3:
                        {
                            Console.Write("- Nhập số thứ tự (STT) phân số muốn xóa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine());
                                Alert(DeletePhanSo(index), "Xóa");
                            }
                            catch
                            {
                                Alert(false, "Xóa");
                            }
                        }
                        break;

                    default:
                        break;
                }
            } while (choice != 4);
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8; 
            GetMenu();
        }
    }
}